package com.VendingMachine.VendingMachine01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendingMachine01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
